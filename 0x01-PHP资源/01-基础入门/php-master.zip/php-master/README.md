##PHP基础教程

##章节目录
- 第1章 [PHP概述](./Chapter1/Chapter1.md)
- 第2章 [变量](./Chapter2/Chapter2.md)
- 第3章 [HTML表单和PHP](./Chapter3/Chapter3.md)
- 第4章 [使用数值](./Chapter4/Chapter4.md)
- 第5章 [使用字符串](./Chapter5/Chapter5.md)
- 第6章 [控制结构](./Chapter6/Chapter6.md)
- 第7章 [使用数组](./Chapter7/Chapter7.md)
- 第8章 [创建Web应用程序](./Chapter8/Chapter8.md)
- 第9章 [cookie和session](./Chapter9/Chapter9.md)
- 第10章 [创建函数](./Chapter10/Chapter10.md)
- 第11章 [文件和目录](./Chapter11/Chapter11.md)
- 第12章 [数据库介绍](./Chapter12/Chapter12.md)
- 第13章 [将所有的组合在一起](./Chapter13/Chapter13.md)

##博文链接
- [博文列表](http://daige.me/tag/php/)
