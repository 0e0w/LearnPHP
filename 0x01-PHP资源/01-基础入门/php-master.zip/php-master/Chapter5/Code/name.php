<?php
    
    print $_GET["name"];
    print $_GET["uid"];
?>