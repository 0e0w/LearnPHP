<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
        "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title>Hello, World!</title>
</head>
<body>
<p>The following was created by PHP: <br />
<?php
/*
 *	Filename: hello3.php
 *	Book reference: Script 1.5
 *	Created by: Larry Ullman
 */

//print "<span style=\"font-weight: bold;\">Hello, world!</span>\n";

?>
<!-- This is an HTML comment. -->
</p>
</body>
</html>