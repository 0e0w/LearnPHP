<?php

define("TITLE", "欢迎daige");

include ("templates/header.html");

?>

<h2>daige已经登录</h2>

<?php
  include ("templates/footer.html");
?>

