<?php

include ("templates/header.html");

?>

<?php

//   header("Location:/login.php");
?>


<?php
  include ("templates/footer.html");
?>

