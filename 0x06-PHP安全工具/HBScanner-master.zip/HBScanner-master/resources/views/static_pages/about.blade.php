@extends('layouts.default')
@section('title', '关于我')
@section('content')
    <h1>关于页</h1>
@stop
